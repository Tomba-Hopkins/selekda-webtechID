console.log('OK')

const client = document.querySelector('.client').cloneNode(true)
document.querySelector('.container').appendChild(client)